package com.shopping.cart.app.exception;

public class PaymentNotFoundException extends Exception{
	
	private static final long serialVersionUID = 381673595344350811L;

	public PaymentNotFoundException(String msg) {
		super(msg);
		
		
	}

	
}
