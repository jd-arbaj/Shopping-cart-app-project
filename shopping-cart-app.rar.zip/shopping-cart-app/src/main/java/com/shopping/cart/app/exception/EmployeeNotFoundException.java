package com.shopping.cart.app.exception;

public class EmployeeNotFoundException extends Exception{
	
	private static final long serialVersionUID = 381673595344350811L;

	public EmployeeNotFoundException(String msg) {
		super(msg);
		
		
	}

	
}
