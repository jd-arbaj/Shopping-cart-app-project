package com.shopping.cart.app.exception;

public class OrderNotFoundException extends Exception{
	
	private static final long serialVersionUID = 381673595344350811L;

	public OrderNotFoundException(String msg) {
		super(msg);
		
		
	}

	
}
