package com.shopping.cart.app.exception;

public class CustomerNotFoundException extends Exception{
	
	
	private static final long serialVersionUID = -1812146068079501468L;

	public CustomerNotFoundException(String msg) {
		super(msg);
		
		
	}

	
}
