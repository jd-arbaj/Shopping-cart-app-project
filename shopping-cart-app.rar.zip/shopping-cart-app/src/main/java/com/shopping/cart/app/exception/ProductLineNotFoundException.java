package com.shopping.cart.app.exception;

public class ProductLineNotFoundException extends Exception{
	
	private static final long serialVersionUID = 381673595344350811L;

	public ProductLineNotFoundException(String msg) {
		super(msg);
		
		
	}

	
}
