package com.shopping.cart.app.exception;

public class OrderDetailNotFoundException extends Exception{
	
	private static final long serialVersionUID = 381673595344350811L;

	public OrderDetailNotFoundException(String msg) {
		super(msg);
		
		
	}

	
}
