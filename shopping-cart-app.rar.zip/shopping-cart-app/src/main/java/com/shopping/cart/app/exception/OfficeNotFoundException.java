package com.shopping.cart.app.exception;

public class OfficeNotFoundException extends Exception{
	
	private static final long serialVersionUID = 381673595344350811L;

	public OfficeNotFoundException(String msg) {
		super(msg);
		
	}

	
}
