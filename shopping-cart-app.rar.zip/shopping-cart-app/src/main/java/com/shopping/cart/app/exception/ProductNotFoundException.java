package com.shopping.cart.app.exception;

public class ProductNotFoundException extends Exception{
	
	private static final long serialVersionUID = 381673595344350811L;

	public ProductNotFoundException(String msg) {
		super(msg);
		
		
	}

	
}
