create database all_products_shopping;
drop database all_products_shopping;
use all_products_shopping;

show tables;

select *from products;
select *from productlines;
select *from payments;
select *from customers;
select *from employees;
select *from orders;
select *from orderdetails;
select *from offices;

